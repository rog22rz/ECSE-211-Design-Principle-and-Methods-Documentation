package ca.mcgill.ecse211.lab1;

import lejos.hardware.motor.*;

/**
 * This class implements the BangBang controller.
 * 
 * @author Roger Zhang
 *
 */

public class BangBangController implements UltrasonicController {

  private final int bandCenter; // offset from the wall
  private final int bandwidth; // width of the dead band
  private final int motorLow; // speed of the motor when set to low
  private final int motorHigh; // speed of the motor when set to high
  private int distance; // distance from the wall according to us sensor

  /**
   * This BangBangController constructor creates a bang bang controller and start the robot moving
   * forward
   * 
   * @param bandCenter the offset from the wall
   * @param bandwidth the width of the dead band
   * @param motorLow the speed of the motor when set to slow
   * @param motorHigh the speed of the motor when set to high
   *
   */

  public BangBangController(int bandCenter, int bandwidth, int motorLow, int motorHigh) {
    // Default Constructor
    this.bandCenter = bandCenter;
    this.bandwidth = bandwidth;
    this.motorLow = motorLow;
    this.motorHigh = motorHigh;
    WallFollowingLab.leftMotor.setSpeed(motorHigh); // Start robot moving forward
    WallFollowingLab.rightMotor.setSpeed(motorHigh);
    WallFollowingLab.leftMotor.forward();
    WallFollowingLab.rightMotor.forward();
  }

  /**
   * This processUSData method takes the distance from the wall according to the us sensor as input
   * and manages the speed of the motors accordingly, bang bang controller style.
   * 
   * @param distance the distance between the robot and the wall, according to the us sensor
   */

  @Override
  public void processUSData(int distance) {
    this.distance = distance;

    int distError = this.bandCenter - this.distance; // The difference between where the robot
                                                     // should be and where it actually is

    if (Math.abs(distError) <= this.bandwidth) { // If the distance from the wall is correct, high
                                                 // speed to both motors making the robot go in straight line
      WallFollowingLab.leftMotor.setSpeed(motorHigh); 
      WallFollowingLab.rightMotor.setSpeed(motorHigh);
      WallFollowingLab.leftMotor.forward();
      WallFollowingLab.rightMotor.forward();
    } else if (distError > 0 && distError >= 15) { // If the robot is too close to the wall, make go
                                                   // backwards while turning right
      WallFollowingLab.rightMotor.setSpeed(motorHigh + 45); 
      WallFollowingLab.leftMotor.setSpeed(motorLow + 35);
      WallFollowingLab.leftMotor.forward();
      WallFollowingLab.rightMotor.backward();
    } else if (distError > 0) { // If the robot is too close from the wall but 15 cm within the
                                // offset from the wall, make it slowly turn right
      WallFollowingLab.leftMotor.setSpeed(motorHigh + 125); 
      WallFollowingLab.rightMotor.setSpeed(motorLow - 20);
      WallFollowingLab.leftMotor.forward();
      WallFollowingLab.rightMotor.forward();
    } else { // If the robot is too far from the wall, make it slowly turn left
      WallFollowingLab.leftMotor.setSpeed(motorLow - 10);
      WallFollowingLab.rightMotor.setSpeed(motorHigh - 38);
      WallFollowingLab.leftMotor.forward();
      WallFollowingLab.rightMotor.forward();
    }

  }

  /**
   * This readUSDistance method returns the distance between the wall and the robot according to the
   * ultrasonic sensor.
   * 
   * @return the distance between the wall and the robot
   */

  @Override
  public int readUSDistance() {
    return this.distance;
  }
}

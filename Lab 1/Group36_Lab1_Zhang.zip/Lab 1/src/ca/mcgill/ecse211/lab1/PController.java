package ca.mcgill.ecse211.lab1;

import lejos.hardware.motor.EV3LargeRegulatedMotor;

/**
 * This class implements the P Controller.
 * 
 * @author Roger Zhang 
 *
 */

public class PController implements UltrasonicController {

  /* Constants */
  private static final int MOTOR_SPEED = 100; // Initial speed of the motor
  private static final int FILTER_OUT = 10; // Number of null signals to filter out before actually
                                            // registering a null signal
  private static final int GAIN = 2; // P constant by which the difference between the offset from
                                     // the wall and the actual distance from the wall is multiplied

  private final int bandCenter; // offset from the wall
  private final int bandWidth; // width of the dead band
  private int distance; // distance from the wall
  private int filterControl; // count counting the number of distances filtered out

  /**
   * This PController constructor creates a p controller and starts the robot moving forward.
   * 
   * @param bandCenter the offset from the wall
   * @param bandwidth the width of the dead band
   */

  public PController(int bandCenter, int bandwidth) {
    this.bandCenter = bandCenter;
    this.bandWidth = bandwidth;
    this.filterControl = 0;

    WallFollowingLab.leftMotor.setSpeed(MOTOR_SPEED); // Initialize motor rolling forward
    WallFollowingLab.rightMotor.setSpeed(MOTOR_SPEED);
    WallFollowingLab.leftMotor.forward();
    WallFollowingLab.rightMotor.forward();
  }

  /**
   * This processUSData method takes the distance red by the us sensor and manages the speed of the
   * motors accordingly, p controller style.
   * 
   * @param distance the distance between the wall and the robot according to the us sensor
   */

  @Override
  public void processUSData(int distance) {

    // rudimentary filter - toss out invalid samples corresponding to null
    // signal.
    // (n.b. this was not included in the Bang-bang controller, but easily
    // could have).
    //
    if (distance >= 255 && filterControl < FILTER_OUT) {
      // bad value, do not set the distance var, however do increment the
      // filter value
      filterControl++;
    } else if (distance >= 255) {
      // We have repeated large values, so there must actually be nothing
      // there: leave the distance alone
      this.distance = distance;
    } else {
      // distance went below 255: reset filter and leave
      // distance alone.
      filterControl = 0;
      this.distance = distance;
    }


    int distError = this.bandCenter - this.distance; // The difference between where the robot
                                                     // should be and where it actually is

    int diff; // The proportional value by which the speed should get modified

    if (Math.abs(distError) <= this.bandWidth) {
      WallFollowingLab.leftMotor.setSpeed(MOTOR_SPEED); // If the distance from the wall is correct,
                                                        // high speed to both motors
      WallFollowingLab.rightMotor.setSpeed(MOTOR_SPEED); // making the robot go in straight line
      WallFollowingLab.leftMotor.forward();
      WallFollowingLab.rightMotor.forward();
    } else if (distError > 0 && distError >= 10) {
      diff = calcGain(distError); // Call the calcGain function which computes the value by which
                                  // the speed should be modified
      diff = (3 * diff);
      WallFollowingLab.rightMotor.setSpeed(MOTOR_SPEED + diff);
      WallFollowingLab.leftMotor.setSpeed(MOTOR_SPEED + diff); // If the robot is too close, go
                                                               // backwards while turning right
      WallFollowingLab.leftMotor.forward();
      WallFollowingLab.rightMotor.backward();
    } else if (distError > 0) { // If the robot is too close to the wall but within 10 cm of the
                                // offset from the wall, slowly turn right
      diff = calcGain(distError); 
      WallFollowingLab.leftMotor.setSpeed(MOTOR_SPEED + diff);
      WallFollowingLab.rightMotor.setSpeed(MOTOR_SPEED);
      WallFollowingLab.leftMotor.forward();
      WallFollowingLab.rightMotor.forward();
    } else { // If the robot is too far from the wall, turn left proportionally to its distance
      diff = calcGain(Math.abs(distError));
      WallFollowingLab.leftMotor.setSpeed(MOTOR_SPEED);
      WallFollowingLab.rightMotor.setSpeed(MOTOR_SPEED + diff);
      WallFollowingLab.leftMotor.forward();
      WallFollowingLab.rightMotor.forward();
    }

  }

  /**
   * This calcGain method takes the the difference between where the robot should be and where it
   * actually is (distError) and computes the proportional value by which the speed should get
   * modified.
   * 
   * @param diff the the difference between where the robot should be and where it actually is
   * @return the proportional value by which the speed should get modified
   */

  int calcGain(int diff) {
    if (diff >= 40)
      diff = 40;
    int correction = GAIN * diff;
    return correction;
  }

  /**
   * This readUSDistance method returns the distance between the wall and the robot according to the
   * ultrasonic sensor.
   * 
   * @return the distance between the wall and the robot
   */

  @Override
  public int readUSDistance() {
    return this.distance;
  }

}
